import { useState, useEffect } from 'react';
import { ArrowLeft, Shield, Users, MessageSquare, BarChart2, Crown, Search } from 'lucide-react';
import { supabase, Profile, Post } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

type Tab = 'stats' | 'users' | 'posts';

type Props = {
  onBack: () => void;
};

const ROLE_COLORS: Record<string, string> = {
  user: 'bg-gray-100 text-gray-600',
  moderator: 'bg-blue-100 text-blue-700',
  admin: 'bg-orange-100 text-orange-700',
  creator: 'bg-amber-100 text-amber-700',
};

const ROLE_LABELS: Record<string, string> = {
  user: 'USUARIO',
  moderator: 'MODERADOR',
  admin: 'ADMIN',
  creator: 'CREADOR',
};

export default function AdminPage({ onBack }: Props) {
  const { profile: myProfile } = useAuth();
  const [tab, setTab] = useState<Tab>('stats');
  const [users, setUsers] = useState<Profile[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [search, setSearch] = useState('');
  const [stats, setStats] = useState({ totalPosts: 0, totalUsers: 0, totalReactions: 0, totalComments: 0 });

  useEffect(() => {
    fetchStats();
    fetchUsers();
    fetchPosts();
  }, []);

  async function fetchStats() {
    const [postsRes, usersRes, reactionsRes, commentsRes] = await Promise.all([
      supabase.from('posts').select('id', { count: 'exact', head: true }),
      supabase.from('profiles').select('id', { count: 'exact', head: true }),
      supabase.from('reactions').select('id', { count: 'exact', head: true }),
      supabase.from('comments').select('id', { count: 'exact', head: true }),
    ]);
    setStats({
      totalPosts: postsRes.count ?? 0,
      totalUsers: usersRes.count ?? 0,
      totalReactions: reactionsRes.count ?? 0,
      totalComments: commentsRes.count ?? 0,
    });
  }

  async function fetchUsers() {
    const { data } = await supabase.from('profiles').select('*').order('created_at', { ascending: false });
    if (data) setUsers(data);
  }

  async function fetchPosts() {
    const { data } = await supabase
      .from('posts')
      .select('*, profiles(username, avatar_emoji), reactions(id), comments(id)')
      .order('created_at', { ascending: false })
      .limit(100);
    if (data) setPosts(data.map((p: Post & { reactions: { id: string }[]; comments: { id: string }[] }) => ({
      ...p,
      reaction_count: p.reactions?.length ?? 0,
      comment_count: p.comments?.length ?? 0,
    })));
  }

  async function setRole(userId: string, role: Profile['role']) {
    await supabase.from('profiles').update({ role }).eq('id', userId);
    fetchUsers();
  }

  async function toggleVerified(userId: string, current: boolean) {
    await supabase.from('profiles').update({ is_verified: !current }).eq('id', userId);
    fetchUsers();
  }

  async function deletePost(postId: string) {
    await supabase.from('posts').delete().eq('id', postId);
    fetchPosts();
    fetchStats();
  }

  const filteredUsers = users.filter(u =>
    u.username.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-b from-red-50/60 to-white">
      <div className="max-w-3xl mx-auto px-4 py-8">
        <button onClick={onBack} className="flex items-center gap-2 text-gray-500 hover:text-gray-700 mb-6 text-sm font-medium transition-colors">
          <ArrowLeft size={18} />
          Volver
        </button>

        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
              <Shield className="text-orange-500" size={22} />
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-900">Panel de Administracion</h2>
              <p className="text-gray-500 text-sm">Gestiona usuarios, quejas y estadísticas de la plataforma.</p>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex bg-white rounded-xl border border-gray-100 p-1 mb-6 shadow-sm">
          {([
            { id: 'stats', label: 'Estadísticas', Icon: BarChart2 },
            { id: 'users', label: 'Usuarios', Icon: Users },
            { id: 'posts', label: 'Quejas', Icon: MessageSquare },
          ] as { id: Tab; label: string; Icon: React.ElementType }[]).map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-semibold transition-all ${
                tab === t.id
                  ? 'bg-red-500 text-white shadow-sm'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <t.Icon size={16} />
              {t.label}
            </button>
          ))}
        </div>

        {/* Stats tab */}
        {tab === 'stats' && (
          <div className="grid grid-cols-2 gap-4">
            {[
              { label: 'Quejas totales', value: stats.totalPosts, color: 'text-red-500', bg: 'bg-red-50' },
              { label: 'Usuarios', value: stats.totalUsers, color: 'text-blue-500', bg: 'bg-blue-50' },
              { label: 'Reacciones', value: stats.totalReactions, color: 'text-green-500', bg: 'bg-green-50' },
              { label: 'Comentarios', value: stats.totalComments, color: 'text-orange-500', bg: 'bg-orange-50' },
            ].map(s => (
              <div key={s.label} className={`${s.bg} rounded-2xl p-6`}>
                <div className={`text-3xl font-extrabold ${s.color}`}>{s.value}</div>
                <div className="text-gray-600 text-sm mt-1 font-medium">{s.label}</div>
              </div>
            ))}
          </div>
        )}

        {/* Users tab */}
        {tab === 'users' && (
          <div>
            <div className="flex gap-2 mb-4">
              <div className="flex-1 relative">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  placeholder="Buscar por nombre de usuario..."
                  className="w-full pl-9 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-red-300"
                />
              </div>
              <button
                onClick={fetchUsers}
                className="px-4 py-2 text-sm font-semibold text-gray-700 border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors"
              >
                Buscar
              </button>
            </div>
            <div className="space-y-3">
              {filteredUsers.map(u => (
                <div key={u.id} className="bg-white rounded-xl border border-gray-100 p-4 flex items-center justify-between shadow-sm">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-gray-800">{u.username}</span>
                      {u.role === 'creator' && <span className="text-amber-500">👑</span>}
                      {u.is_verified && <span className="text-blue-500 text-sm">✓</span>}
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${ROLE_COLORS[u.role]}`}>
                        {ROLE_LABELS[u.role]}
                      </span>
                      {u.bio && <span className="text-gray-400 text-xs italic">{u.bio.slice(0, 40)}</span>}
                    </div>
                  </div>
                  {myProfile?.id !== u.id && (
                    <div className="flex gap-2">
                      <button
                        onClick={() => setRole(u.id, u.role === 'creator' ? 'user' : 'creator')}
                        title="Cambiar a creador"
                        className="w-8 h-8 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-600 flex items-center justify-center transition-colors"
                      >
                        <Crown size={14} />
                      </button>
                      <button
                        onClick={() => setRole(u.id, u.role === 'moderator' ? 'user' : 'moderator')}
                        title="Cambiar a moderador"
                        className="w-8 h-8 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-600 flex items-center justify-center transition-colors text-xs font-bold"
                      >
                        M
                      </button>
                      <button
                        onClick={() => toggleVerified(u.id, u.is_verified)}
                        title="Verificar usuario"
                        className="w-8 h-8 rounded-lg bg-green-50 hover:bg-green-100 text-green-600 flex items-center justify-center transition-colors text-xs"
                      >
                        ✓
                      </button>
                    </div>
                  )}
                </div>
              ))}
              {filteredUsers.length === 0 && (
                <div className="text-center py-8 text-gray-400 text-sm">No se encontraron usuarios</div>
              )}
            </div>
          </div>
        )}

        {/* Posts tab */}
        {tab === 'posts' && (
          <div className="space-y-3">
            {posts.map(post => (
              <div key={post.id} className="bg-white rounded-xl border border-gray-100 p-4 shadow-sm">
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0 mr-3">
                    <p className="font-semibold text-gray-800 text-sm truncate">{post.title}</p>
                    <p className="text-xs text-gray-400 mt-0.5">
                      {post.is_anonymous ? 'Anónimo' : post.profiles?.username} · {post.category} · {post.urgency}
                    </p>
                    <p className="text-gray-600 text-xs mt-1.5 line-clamp-2">{post.content}</p>
                  </div>
                  <button
                    onClick={() => deletePost(post.id)}
                    className="shrink-0 text-xs text-red-500 hover:bg-red-50 px-3 py-1.5 rounded-lg border border-red-200 transition-colors font-medium"
                  >
                    Eliminar
                  </button>
                </div>
              </div>
            ))}
            {posts.length === 0 && (
              <div className="text-center py-8 text-gray-400 text-sm">No hay quejas aún</div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
