import { useState, useEffect, useCallback } from 'react';
import { Flame, TrendingUp, Star, Eye, Clock } from 'lucide-react';
import { supabase, Post } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import PostCard from '../components/PostCard';

const CATEGORIES = [
  { id: 'todos', label: 'Todos' },
  { id: 'trabajo', label: 'Trabajo', emoji: '💼' },
  { id: 'relaciones', label: 'Relaciones', emoji: '❤️' },
  { id: 'salud', label: 'Salud', emoji: '📱' },
  { id: 'dinero', label: 'Dinero', emoji: '💎' },
  { id: 'familia', label: 'Familia', emoji: '👨‍👩‍👧‍👦' },
];

const SORT_OPTIONS = [
  { id: 'recientes', label: 'Recientes', Icon: Clock },
  { id: 'popular', label: 'Popular', Icon: TrendingUp },
  { id: 'destacadas', label: 'Destacadas', Icon: Star },
  { id: 'vistas', label: 'Más vistas', Icon: Eye },
];

type Props = {
  onDesahogarClick: () => void;
  refreshKey: number;
};

export default function HomePage({ onDesahogarClick, refreshKey }: Props) {
  const { user } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [category, setCategory] = useState('todos');
  const [sort, setSort] = useState('recientes');
  const [userReactions, setUserReactions] = useState<Set<string>>(new Set());

  const fetchPosts = useCallback(async () => {
    setLoading(true);
    let query = supabase
      .from('posts')
      .select(`
        *,
        profiles (id, username, avatar_emoji, is_verified, role),
        reactions (id, user_id, reaction_type),
        comments (id)
      `);

    if (category !== 'todos') query = query.eq('category', category);

    if (sort === 'recientes') query = query.order('created_at', { ascending: false });
    else if (sort === 'vistas') query = query.order('views', { ascending: false });
    else if (sort === 'popular') query = query.order('created_at', { ascending: false });
    else query = query.order('created_at', { ascending: false });

    query = query.limit(50);

    const { data, error } = await query;
    if (!error && data) {
      const enriched = data.map((p: Post & { reactions: { id: string; user_id: string; reaction_type: string }[]; comments: { id: string }[] }) => ({
        ...p,
        reaction_count: p.reactions?.length ?? 0,
        comment_count: p.comments?.length ?? 0,
      }));

      if (sort === 'popular') enriched.sort((a: Post, b: Post) => (b.reaction_count ?? 0) - (a.reaction_count ?? 0));
      if (sort === 'destacadas') enriched.sort((a: Post, b: Post) => (b.comment_count ?? 0) - (a.comment_count ?? 0));

      setPosts(enriched);
    }
    setLoading(false);
  }, [category, sort]);

  useEffect(() => {
    fetchPosts();
  }, [fetchPosts, refreshKey]);

  useEffect(() => {
    if (!user) return;
    supabase
      .from('reactions')
      .select('post_id')
      .eq('user_id', user.id)
      .then(({ data }) => {
        if (data) setUserReactions(new Set(data.map((r: { post_id: string }) => r.post_id)));
      });
  }, [user, refreshKey]);

  async function handleReact(postId: string) {
    if (!user) return;
    const alreadyReacted = userReactions.has(postId);
    if (alreadyReacted) {
      await supabase.from('reactions').delete().eq('post_id', postId).eq('user_id', user.id);
      setUserReactions(prev => { const s = new Set(prev); s.delete(postId); return s; });
    } else {
      await supabase.from('reactions').insert({ post_id: postId, user_id: user.id, reaction_type: 'heart' });
      setUserReactions(prev => new Set([...prev, postId]));
    }
    fetchPosts();
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-red-50/60 to-white">
      <div className="max-w-2xl mx-auto px-4 py-10">
        {/* Hero */}
        <div className="text-center mb-10">
          <Flame className="mx-auto text-red-400 mb-4" size={40} />
          <h1 className="text-4xl font-extrabold text-gray-900 mb-3">Suelta lo que sientes</h1>
          <p className="text-gray-500 text-base max-w-md mx-auto leading-relaxed">
            Todos tenemos días malos. Aquí puedes desahogarte sin que nadie te juzgue.
            Comparte tu queja y recibe el apoyo de la comunidad.
          </p>
        </div>

        {/* Category filter */}
        <div className="flex gap-2 flex-wrap mb-3">
          {CATEGORIES.map(cat => (
            <button
              key={cat.id}
              onClick={() => setCategory(cat.id)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-semibold border transition-all ${
                category === cat.id
                  ? 'bg-red-500 text-white border-red-500 shadow-sm'
                  : 'bg-white text-gray-600 border-gray-200 hover:border-gray-300'
              }`}
            >
              {cat.emoji && <span>{cat.emoji}</span>}
              {cat.label}
            </button>
          ))}
        </div>

        {/* Sort filter */}
        <div className="flex items-center gap-2 mb-8 flex-wrap">
          <span className="text-sm text-gray-500 font-medium">Ordenar por:</span>
          {SORT_OPTIONS.map(opt => (
            <button
              key={opt.id}
              onClick={() => setSort(opt.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm border transition-all ${
                sort === opt.id
                  ? 'bg-red-500 text-white border-red-500'
                  : 'bg-white text-gray-500 border-gray-200 hover:border-gray-300'
              }`}
            >
              <opt.Icon size={13} />
              {opt.label}
            </button>
          ))}
        </div>

        {/* Posts */}
        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="bg-white rounded-2xl border border-gray-100 p-5 animate-pulse">
                <div className="h-4 bg-gray-100 rounded w-1/3 mb-3" />
                <div className="h-5 bg-gray-100 rounded w-3/4 mb-2" />
                <div className="h-4 bg-gray-100 rounded w-full mb-1" />
                <div className="h-4 bg-gray-100 rounded w-2/3" />
              </div>
            ))}
          </div>
        ) : posts.length === 0 ? (
          <div className="text-center py-20">
            <Flame className="mx-auto text-gray-200 mb-4" size={48} />
            <h3 className="text-lg font-semibold text-gray-700 mb-1">No hay quejas hoy</h3>
            <p className="text-gray-400 text-sm mb-6">Se el primero en desahogarte</p>
            <button
              onClick={onDesahogarClick}
              className="bg-red-500 hover:bg-red-600 text-white px-6 py-3 rounded-full font-semibold transition-colors"
            >
              Publicar queja
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {posts.map(post => (
              <PostCard
                key={post.id}
                post={post}
                onReact={handleReact}
                reacted={userReactions.has(post.id)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
