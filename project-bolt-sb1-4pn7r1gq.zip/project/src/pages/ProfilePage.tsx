import { useState, useEffect } from 'react';
import { ArrowLeft, User, CreditCard as Edit2, Check, X } from 'lucide-react';
import { supabase, Post } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import PostCard from '../components/PostCard';

type Props = {
  onBack: () => void;
};

const EMOJIS = ['😊', '😎', '🤔', '😴', '🥳', '😤', '🤯', '🥺', '😂', '🙃', '😈', '👻', '🤖', '🦁', '🐺'];
const ROLE_LABELS: Record<string, string> = {
  user: 'Usuario',
  moderator: 'Moderador',
  admin: 'Administración',
  creator: 'Creador',
};

export default function ProfilePage({ onBack }: Props) {
  const { profile, refreshProfile } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [editing, setEditing] = useState(false);
  const [username, setUsername] = useState(profile?.username ?? '');
  const [bio, setBio] = useState(profile?.bio ?? '');
  const [avatarEmoji, setAvatarEmoji] = useState(profile?.avatar_emoji ?? '😊');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!profile) return;
    setUsername(profile.username);
    setBio(profile.bio);
    setAvatarEmoji(profile.avatar_emoji);

    supabase
      .from('posts')
      .select('*, reactions(id), comments(id)')
      .eq('user_id', profile.id)
      .order('created_at', { ascending: false })
      .then(({ data }) => {
        if (data) {
          setPosts(data.map((p: Post & { reactions: { id: string }[]; comments: { id: string }[] }) => ({
            ...p,
            reaction_count: p.reactions?.length ?? 0,
            comment_count: p.comments?.length ?? 0,
          })));
        }
      });
  }, [profile]);

  async function handleSave() {
    if (!profile) return;
    setSaving(true);
    setError('');
    const { error } = await supabase
      .from('profiles')
      .update({ username: username.trim(), bio: bio.trim(), avatar_emoji: avatarEmoji })
      .eq('id', profile.id);
    if (error) setError('Error al guardar. El nombre de usuario puede estar en uso.');
    else { await refreshProfile(); setEditing(false); }
    setSaving(false);
  }

  if (!profile) return null;

  return (
    <div className="min-h-screen bg-gradient-to-b from-red-50/60 to-white">
      <div className="max-w-2xl mx-auto px-4 py-8">
        <button onClick={onBack} className="flex items-center gap-2 text-gray-500 hover:text-gray-700 mb-6 text-sm font-medium transition-colors">
          <ArrowLeft size={18} />
          Volver
        </button>

        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 mb-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-red-50 rounded-2xl flex items-center justify-center text-3xl">
                {editing ? avatarEmoji : profile.avatar_emoji}
              </div>
              <div>
                {editing ? (
                  <input
                    value={username}
                    onChange={e => setUsername(e.target.value)}
                    className="text-xl font-bold text-gray-900 border-b-2 border-red-300 focus:outline-none bg-transparent w-full"
                  />
                ) : (
                  <div className="flex items-center gap-2">
                    <h2 className="text-xl font-bold text-gray-900">{profile.username}</h2>
                    {profile.is_verified && <span className="text-blue-500">✓</span>}
                  </div>
                )}
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full font-medium uppercase">
                    {ROLE_LABELS[profile.role] ?? profile.role}
                  </span>
                </div>
              </div>
            </div>
            {!editing ? (
              <button onClick={() => setEditing(true)} className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-700 border border-gray-200 px-3 py-1.5 rounded-lg transition-colors">
                <Edit2 size={14} />
                Editar
              </button>
            ) : (
              <div className="flex gap-2">
                <button onClick={handleSave} disabled={saving} className="flex items-center gap-1 text-sm text-white bg-red-500 hover:bg-red-600 px-3 py-1.5 rounded-lg disabled:opacity-60 transition-colors">
                  <Check size={14} />
                  {saving ? 'Guardando...' : 'Guardar'}
                </button>
                <button onClick={() => { setEditing(false); setError(''); }} className="p-1.5 text-gray-400 hover:text-gray-600 border border-gray-200 rounded-lg transition-colors">
                  <X size={14} />
                </button>
              </div>
            )}
          </div>

          {editing && (
            <div className="mb-4">
              <label className="block text-xs font-medium text-gray-500 mb-2">Elige tu emoji</label>
              <div className="flex flex-wrap gap-2">
                {EMOJIS.map(e => (
                  <button
                    key={e}
                    onClick={() => setAvatarEmoji(e)}
                    className={`w-9 h-9 rounded-xl text-xl flex items-center justify-center transition-all ${
                      avatarEmoji === e ? 'bg-red-100 ring-2 ring-red-400' : 'hover:bg-gray-100'
                    }`}
                  >
                    {e}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">Bio</label>
            {editing ? (
              <textarea
                value={bio}
                onChange={e => setBio(e.target.value)}
                rows={3}
                placeholder="Cuéntanos algo sobre ti..."
                className="w-full px-3 py-2 rounded-xl border border-gray-200 focus:outline-none focus:border-red-300 text-sm text-gray-700 resize-none"
              />
            ) : (
              <p className="text-gray-600 text-sm">{profile.bio || 'Sin bio todavía.'}</p>
            )}
          </div>

          {error && <div className="mt-3 text-red-500 text-sm bg-red-50 px-3 py-2 rounded-lg">{error}</div>}
        </div>

        <div className="flex items-center gap-2 mb-4">
          <User size={18} className="text-gray-400" />
          <h3 className="font-semibold text-gray-700">Mis quejas ({posts.length})</h3>
        </div>

        {posts.length === 0 ? (
          <div className="text-center py-12 text-gray-400">
            <p>Aún no has publicado ninguna queja.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {posts.map(post => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
