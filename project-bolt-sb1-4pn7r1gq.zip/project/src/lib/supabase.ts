import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Profile = {
  id: string;
  username: string;
  bio: string;
  role: 'user' | 'moderator' | 'admin' | 'creator';
  is_verified: boolean;
  avatar_emoji: string;
  created_at: string;
};

export type Post = {
  id: string;
  user_id: string | null;
  title: string;
  content: string;
  category: string;
  mood: string;
  urgency: 'baja' | 'media' | 'alta' | 'critica';
  is_anonymous: boolean;
  views: number;
  created_at: string;
  profiles?: Profile | null;
  reactions?: Reaction[];
  comments?: Comment[];
  reaction_count?: number;
  comment_count?: number;
};

export type Reaction = {
  id: string;
  post_id: string;
  user_id: string;
  reaction_type: string;
  created_at: string;
};

export type Comment = {
  id: string;
  post_id: string;
  user_id: string;
  content: string;
  created_at: string;
  profiles?: Profile | null;
};
