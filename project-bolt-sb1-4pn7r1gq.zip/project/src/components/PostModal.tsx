import { useState } from 'react';
import { X, EyeOff, Send } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

type Props = {
  onClose: () => void;
  onSuccess: () => void;
};

const CATEGORIES = [
  { id: 'trabajo', label: 'Trabajo', emoji: '💼' },
  { id: 'relaciones', label: 'Relaciones', emoji: '❤️' },
  { id: 'salud', label: 'Salud', emoji: '📱' },
  { id: 'dinero', label: 'Dinero', emoji: '💎' },
  { id: 'familia', label: 'Familia', emoji: '👨‍👩‍👧‍👦' },
  { id: 'escuela', label: 'Escuela', emoji: '📚' },
  { id: 'sociedad', label: 'Sociedad', emoji: '🌍' },
  { id: 'salud_mental', label: 'Salud Mental', emoji: '🧠' },
  { id: 'vivienda', label: 'Vivienda', emoji: '🏠' },
  { id: 'transporte', label: 'Transporte', emoji: '🚌' },
  { id: 'alimentacion', label: 'Alimentación', emoji: '🍽️' },
  { id: 'soledad', label: 'Soledad', emoji: '😔' },
  { id: 'autoestima', label: 'Autoestima', emoji: '📱' },
  { id: 'otro', label: 'Otro', emoji: '🙈' },
];

const MOODS = [
  { id: 'frustrado', label: 'Frustrado/a', emoji: '😤' },
  { id: 'triste', label: 'Triste', emoji: '😢' },
  { id: 'enojado', label: 'Enojado/a', emoji: '😡' },
  { id: 'ansioso', label: 'Ansioso/a', emoji: '😨' },
  { id: 'abramado', label: 'Abramado/a', emoji: '😵' },
  { id: 'cansado', label: 'Cansado/a', emoji: '😩' },
  { id: 'decepcionado', label: 'Decepcionado/a', emoji: '😞' },
  { id: 'con_esperanza', label: 'Con esperanza', emoji: '🙏' },
];

const URGENCIES = [
  { id: 'baja', label: 'Baja', color: 'text-green-500', dot: 'bg-green-500' },
  { id: 'media', label: 'Medios de comunicación', color: 'text-yellow-500', dot: 'bg-yellow-500' },
  { id: 'alta', label: 'Alta', color: 'text-orange-500', dot: 'bg-orange-500' },
  { id: 'critica', label: 'Crítica', color: 'text-red-600', dot: 'bg-red-600' },
];

export default function PostModal({ onClose, onSuccess }: Props) {
  const { user, profile } = useAuth();
  const [category, setCategory] = useState('');
  const [mood, setMood] = useState('');
  const [urgency, setUrgency] = useState<'baja' | 'media' | 'alta' | 'critica'>('baja');
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit() {
    if (!category) { setError('Selecciona una categoría'); return; }
    if (!title.trim()) { setError('Escribe un título'); return; }
    if (!content.trim()) { setError('Escribe tu desahogo'); return; }
    if (!user) { setError('Debes iniciar sesión'); return; }

    setLoading(true);
    setError('');

    const { error: err } = await supabase.from('posts').insert({
      user_id: isAnonymous ? null : user.id,
      title: title.trim(),
      content: content.trim(),
      category,
      mood: mood || 'frustrado',
      urgency,
      is_anonymous: isAnonymous,
    });

    setLoading(false);
    if (err) {
      setError('Error al publicar. Intenta de nuevo.');
    } else {
      onSuccess();
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-2xl">
        <div className="sticky top-0 bg-white z-10 flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <h2 className="text-xl font-bold text-gray-900">Desahogarte</h2>
          <button onClick={onClose} className="p-1 text-gray-400 hover:text-gray-600 transition-colors">
            <X size={20} />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Category */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-3">Categoría</label>
            <div className="grid grid-cols-4 gap-2">
              {CATEGORIES.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setCategory(cat.id)}
                  className={`flex flex-col items-center gap-1 p-3 rounded-xl border-2 transition-all text-xs font-medium ${
                    category === cat.id
                      ? 'border-red-400 bg-red-50 text-red-600'
                      : 'border-gray-200 hover:border-gray-300 text-gray-600'
                  }`}
                >
                  <span className="text-xl">{cat.emoji}</span>
                  <span className="text-center leading-tight">{cat.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Mood */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-3">¿Cómo te sientes?</label>
            <div className="grid grid-cols-4 gap-2">
              {MOODS.map(m => (
                <button
                  key={m.id}
                  onClick={() => setMood(m.id)}
                  className={`flex flex-col items-center gap-1 p-3 rounded-xl border-2 transition-all text-xs font-medium ${
                    mood === m.id
                      ? 'border-red-400 bg-red-50 text-red-600'
                      : 'border-gray-200 hover:border-gray-300 text-gray-600'
                  }`}
                >
                  <span className="text-xl">{m.emoji}</span>
                  <span className="text-center leading-tight">{m.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Urgency */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-3">Urgencia</label>
            <div className="flex gap-2 flex-wrap">
              {URGENCIES.map(u => (
                <button
                  key={u.id}
                  onClick={() => setUrgency(u.id as 'baja' | 'media' | 'alta' | 'critica')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-full border-2 transition-all text-sm font-medium ${
                    urgency === u.id
                      ? `border-current ${u.color} bg-opacity-5`
                      : 'border-gray-200 text-gray-500 hover:border-gray-300'
                  }`}
                >
                  <span className={`w-2.5 h-2.5 rounded-full ${u.dot}`} />
                  {u.label}
                </button>
              ))}
            </div>
          </div>

          {/* Title */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Título</label>
            <input
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="Resume tu queja en una linea..."
              maxLength={120}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-red-300 focus:ring-2 focus:ring-red-100 text-gray-800 placeholder-gray-400"
            />
          </div>

          {/* Content */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Cuéntalo todo</label>
            <textarea
              value={content}
              onChange={e => setContent(e.target.value.slice(0, 2000))}
              placeholder="Aqui puedes soltar todo lo que sientes. Nadie te juzga..."
              rows={5}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-red-300 focus:ring-2 focus:ring-red-100 text-gray-800 placeholder-gray-400 resize-none"
            />
            <div className="text-right text-xs text-gray-400 mt-1">{content.length}/2000</div>
          </div>

          {error && (
            <div className="text-red-500 text-sm bg-red-50 px-4 py-2 rounded-lg">{error}</div>
          )}

          {/* Anonymous toggle */}
          <button
            onClick={() => setIsAnonymous(!isAnonymous)}
            className={`flex items-center gap-2 px-4 py-2 rounded-full border-2 text-sm font-medium transition-all ${
              isAnonymous
                ? 'border-red-400 text-red-600 bg-red-50'
                : 'border-gray-200 text-gray-500 hover:border-gray-300'
            }`}
          >
            <EyeOff size={16} />
            Anónimo
          </button>

          {/* Submit */}
          <button
            onClick={handleSubmit}
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 bg-red-500 hover:bg-red-600 disabled:opacity-60 text-white py-3.5 rounded-xl font-semibold text-base transition-colors"
          >
            <Send size={18} />
            {loading ? 'Publicando...' : 'Publicar queja'}
          </button>
        </div>
      </div>
    </div>
  );
}
