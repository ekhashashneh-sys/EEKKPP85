import { Flame, MessageCircle, Shield, User, LogIn, LogOut } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

type View = 'home' | 'profile' | 'admin' | 'auth';

type Props = {
  currentView: View;
  onNavigate: (view: View) => void;
  onDesahogarClick: () => void;
};

export default function Navbar({ currentView, onNavigate, onDesahogarClick }: Props) {
  const { user, profile, signOut } = useAuth();

  const isAdmin = profile?.role === 'admin' || profile?.role === 'creator';

  return (
    <nav className="sticky top-0 z-40 bg-white border-b border-gray-100 shadow-sm">
      <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
        <button
          onClick={() => onNavigate('home')}
          className="flex items-center gap-2 hover:opacity-80 transition-opacity"
        >
          <Flame className="text-red-500" size={24} />
          <div>
            <div className="font-bold text-gray-900 text-lg leading-tight">Desahogo</div>
            <div className="text-gray-400 text-xs leading-tight">Suelta lo que sientes</div>
          </div>
        </button>

        <div className="flex items-center gap-3">
          <button
            onClick={onDesahogarClick}
            className="flex items-center gap-2 bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-full font-semibold text-sm transition-colors"
          >
            <MessageCircle size={16} />
            Desahogarte
          </button>

          {user ? (
            <>
              {isAdmin && (
                <button
                  onClick={() => onNavigate('admin')}
                  className={`p-2 rounded-full transition-colors ${
                    currentView === 'admin'
                      ? 'text-red-500 bg-red-50'
                      : 'text-gray-400 hover:text-gray-600 hover:bg-gray-50'
                  }`}
                  title="Panel de Administración"
                >
                  <Shield size={20} />
                </button>
              )}
              <button
                onClick={() => onNavigate('profile')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-full border transition-colors ${
                  currentView === 'profile'
                    ? 'border-red-200 bg-red-50 text-red-600'
                    : 'border-gray-200 hover:border-gray-300 text-gray-700'
                }`}
              >
                <User size={16} />
                <span className="text-sm font-medium">Perfil</span>
                {profile && (
                  <span className="text-base leading-none">{profile.avatar_emoji}</span>
                )}
                {profile?.is_verified && (
                  <span className="text-blue-500 text-xs">✓</span>
                )}
              </button>
              <button
                onClick={signOut}
                className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
                title="Cerrar sesión"
              >
                <LogOut size={20} />
              </button>
            </>
          ) : (
            <button
              onClick={() => onNavigate('auth')}
              className="flex items-center gap-2 text-gray-700 hover:text-gray-900 transition-colors text-sm font-medium"
            >
              <LogIn size={18} />
              Ingresar
            </button>
          )}
        </div>
      </div>
    </nav>
  );
}
