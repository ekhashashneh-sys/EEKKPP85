import { Heart, MessageCircle, Eye, Clock } from 'lucide-react';
import { Post } from '../lib/supabase';

const CATEGORY_EMOJIS: Record<string, string> = {
  trabajo: '💼', relaciones: '❤️', salud: '📱', dinero: '💎',
  familia: '👨‍👩‍👧‍👦', escuela: '📚', sociedad: '🌍', salud_mental: '🧠',
  vivienda: '🏠', transporte: '🚌', alimentacion: '🍽️', soledad: '😔',
  autoestima: '📱', otro: '🙈',
};

const URGENCY_COLORS: Record<string, string> = {
  baja: 'bg-green-100 text-green-700',
  media: 'bg-yellow-100 text-yellow-700',
  alta: 'bg-orange-100 text-orange-700',
  critica: 'bg-red-100 text-red-700',
};

const MOOD_EMOJIS: Record<string, string> = {
  frustrado: '😤', triste: '😢', enojado: '😡', ansioso: '😨',
  abramado: '😵', cansado: '😩', decepcionado: '😞', con_esperanza: '🙏',
};

function timeAgo(date: string) {
  const diff = Date.now() - new Date(date).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'ahora';
  if (mins < 60) return `hace ${mins}m`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `hace ${hrs}h`;
  return `hace ${Math.floor(hrs / 24)}d`;
}

type Props = {
  post: Post;
  onReact?: (postId: string) => void;
  reacted?: boolean;
};

export default function PostCard({ post, onReact, reacted }: Props) {
  const emoji = CATEGORY_EMOJIS[post.category] ?? '📌';
  const moodEmoji = MOOD_EMOJIS[post.mood] ?? '😐';
  const authorName = post.is_anonymous ? 'Anónimo' : (post.profiles?.username ?? 'Usuario');
  const authorEmoji = post.is_anonymous ? '👤' : (post.profiles?.avatar_emoji ?? '😊');

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow p-5">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="text-lg">{authorEmoji}</span>
          <div>
            <span className="font-semibold text-gray-800 text-sm">{authorName}</span>
            {post.profiles?.is_verified && !post.is_anonymous && (
              <span className="ml-1 text-blue-500 text-xs">✓</span>
            )}
            <div className="flex items-center gap-1 text-xs text-gray-400">
              <Clock size={11} />
              {timeAgo(post.created_at)}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm">{moodEmoji}</span>
          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${URGENCY_COLORS[post.urgency]}`}>
            {post.urgency}
          </span>
          <span className="flex items-center gap-1 text-xs bg-gray-100 px-2 py-0.5 rounded-full text-gray-600">
            <span>{emoji}</span>
            <span className="capitalize">{post.category.replace('_', ' ')}</span>
          </span>
        </div>
      </div>

      <h3 className="font-bold text-gray-900 text-base mb-2 leading-snug">{post.title}</h3>
      <p className="text-gray-600 text-sm leading-relaxed line-clamp-3">{post.content}</p>

      <div className="flex items-center gap-4 mt-4 pt-3 border-t border-gray-50">
        <button
          onClick={() => onReact?.(post.id)}
          className={`flex items-center gap-1.5 text-sm transition-colors ${
            reacted ? 'text-red-500' : 'text-gray-400 hover:text-red-400'
          }`}
        >
          <Heart size={15} fill={reacted ? 'currentColor' : 'none'} />
          <span>{post.reaction_count ?? 0}</span>
        </button>
        <div className="flex items-center gap-1.5 text-gray-400 text-sm">
          <MessageCircle size={15} />
          <span>{post.comment_count ?? 0}</span>
        </div>
        <div className="flex items-center gap-1.5 text-gray-400 text-sm ml-auto">
          <Eye size={15} />
          <span>{post.views}</span>
        </div>
      </div>
    </div>
  );
}
