import { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Navbar from './components/Navbar';
import PostModal from './components/PostModal';
import AuthModal from './components/AuthModal';
import HomePage from './pages/HomePage';
import ProfilePage from './pages/ProfilePage';
import AdminPage from './pages/AdminPage';

type View = 'home' | 'profile' | 'admin' | 'auth';

function AppContent() {
  const { user, profile } = useAuth();
  const [view, setView] = useState<View>('home');
  const [showPost, setShowPost] = useState(false);
  const [showAuth, setShowAuth] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  function handleDesahogarClick() {
    if (!user) setShowAuth(true);
    else setShowPost(true);
  }

  function handleNavigate(v: View) {
    if (v === 'auth') { setShowAuth(true); return; }
    if ((v === 'profile' || v === 'admin') && !user) { setShowAuth(true); return; }
    if (v === 'admin' && profile?.role !== 'admin' && profile?.role !== 'creator') return;
    setView(v);
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar
        currentView={view}
        onNavigate={handleNavigate}
        onDesahogarClick={handleDesahogarClick}
      />

      {view === 'home' && (
        <HomePage
          onDesahogarClick={handleDesahogarClick}
          refreshKey={refreshKey}
        />
      )}
      {view === 'profile' && user && (
        <ProfilePage onBack={() => setView('home')} />
      )}
      {view === 'admin' && user && (profile?.role === 'admin' || profile?.role === 'creator') && (
        <AdminPage onBack={() => setView('home')} />
      )}

      {showPost && (
        <PostModal
          onClose={() => setShowPost(false)}
          onSuccess={() => { setShowPost(false); setRefreshKey(k => k + 1); }}
        />
      )}
      {showAuth && (
        <AuthModal onClose={() => setShowAuth(false)} />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
